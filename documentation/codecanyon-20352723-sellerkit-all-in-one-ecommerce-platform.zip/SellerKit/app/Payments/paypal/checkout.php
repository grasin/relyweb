<?php 
	$response[] = '<button onclick="location.href=\'api/paypal\?order='.$order.'\'" class="payment" id="pp"><img src="assets/paypal.svg"><h5>'.e("PayPal").'</h5></button>'; 
?>