{!! $header !!}
<div class="container landing-cover">
	<div class="not-found">
		<h1>404</h1>
		<h5>{{ translate("Sorry , This page does not exist") }}</h5>
	</div>
</div>
{!! $footer !!}