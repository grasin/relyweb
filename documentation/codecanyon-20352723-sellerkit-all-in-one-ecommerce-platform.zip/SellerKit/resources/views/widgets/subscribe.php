<div class="subscribe">
	<h5 class="col-md-8"><?=translate('Subscribe to our newsletter')?></h5>
	<div class="col-md-4">
		<div class="relative">
			<input placeholder="<?=translate('E-mail address')?>" id="email" class="subscribe-email"/>
			<button class="subscribe-submit" id="subscribe"><?=translate('Subscribe')?></button>
		</div>
	</div>
	<div class="clearfix"></div>
</div>	